# GLORIA: GeneraLization with Chain of Thought for Biomedical AI

**BLAH9 Task** 


**Team**

Nina Hosseini-Kivanani, University of Luxembourg, Faculty of Science, Technology and Medicine (FSTM), Department of Computer Science

Dimitra Anastasiou, Luxembourg Institute of Science and Technology (LIST)

Davide Liga, University of Luxembourg, Faculty of Science, Technology and Medicine (FSTM), Department of Computer Science (DCS)

**References**
